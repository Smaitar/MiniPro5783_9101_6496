﻿namespace BO
{
    public enum Category { ring, bracelet, necklace, earring, sets };
    public enum OrderStatus { Confirmation, Sent, Supplied };
}
