﻿

namespace DO;

public enum Category { ring, bracelet, necklace, earring, sets };

