﻿using System;
//namespace Targil0
//{
//    partial class Program
//    {
//        static void Main(String[] args)
//        {
//            Welcome9101();
//            Welcome6496();
//            Console.ReadKey();
//        }
//        static partial void Welcome6496();
//        private static void Welcome9101()
//        {
//            Console.Write("Enter your name: ");
//            string username = Console.ReadLine();
//            Console.WriteLine("{0}, welcome to my first console application", username);
//        }
//    }
//}


static void Main(String[] args) { }